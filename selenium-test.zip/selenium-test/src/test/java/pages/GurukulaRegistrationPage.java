package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.How;

public class GurukulaRegistrationPage {
	
	WebDriver driver;

	public GurukulaRegistrationPage(WebDriver driver) {
		this.driver = driver;
	}
	
	@FindBy(how = How.XPATH, using = ".//h1[contains(text(),'Registration']")
	WebElement registrationLabel;
	
	public boolean verifyRegistrationLabel() {
		
		if(registrationLabel.isDisplayed()) {
			System.out.println("register label displayed");
			return true;
		} else {
			System.out.println("register label not displayed");
			return false;
		}
			
	}
	
	

}
