package tests;

import static org.testng.Assert.assertEquals;

import org.openqa.selenium.support.PageFactory;
import org.testng.annotations.Test;

import pages.GurukulaHomePage;
import pages.GurukulaRegistrationPage;
import testbase.TestBase;


public class RegisterNewAccountTest extends TestBase{
	
  @Test
  public void init() {
	  
	  GurukulaHomePage gurukulaHomePage = PageFactory.initElements(driver, GurukulaHomePage.class);
	  boolean homePageDisplayed= gurukulaHomePage.verifyHomeButtonDisplayed();
	  assertEquals(homePageDisplayed, true, "Home page displayed");
	  gurukulaHomePage.clickOnRegisterLink();
	  
	  GurukulaRegistrationPage gurukulaRegistrationPage= PageFactory.initElements(driver, GurukulaRegistrationPage.class);
	  boolean registrationLabelDisplayed = gurukulaRegistrationPage.verifyRegistrationLabel();
	  assertEquals(registrationLabelDisplayed, true, "Registration label displayed");
	  	  
	  
  }
}
