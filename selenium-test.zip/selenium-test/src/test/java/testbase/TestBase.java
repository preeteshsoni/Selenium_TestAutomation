package testbase;

import org.testng.annotations.Test;
import org.testng.annotations.BeforeSuite;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.testng.annotations.AfterSuite;

public class TestBase {

	public WebDriver driver;

	@BeforeSuite
	public void beforeSuite() {

		System.setProperty("webdriver.gecko.driver", "D:\\selenium_workspace\\selenium-test\\drivers\\geckodriver.exe");
		driver = new FirefoxDriver();

		driver.manage().window().maximize();
		// Implicit wait
		driver.manage().timeouts().implicitlyWait(20, TimeUnit.SECONDS);
		driver.get("http://127.0.0.1:8080/#/");

	}

	@AfterSuite
	public void afterSuite() {

		
		driver.close(); 
		//driver.quit();
		 
	}

}
